require 'test_helper'

class LegResultTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
